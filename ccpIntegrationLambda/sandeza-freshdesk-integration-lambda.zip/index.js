const fdcontroller = require("./controller");

exports.handler =  async function(event) {
    console.log("------------------------------------------------");
    console.log(JSON.stringify(event));
    let fromNumber = event.Details.ContactData.CustomerEndpoint.Address;  //"+18336624150";
    let customerInfo = await fdcontroller().FDContactAction(encodeURIComponent(fromNumber));
    console.log(JSON.stringify(customerInfo));
    console.log("------------------------------------------------");
    return ({"customerInfo" : JSON.stringify(customerInfo)})
};
