const fdcontroller = require("./controller");

exports.handler =  async function(event) {
    console.log("------------------------------------------------");
    console.log(JSON.stringify(event));
    let fromNumber = event.Details.ContactData.Attributes.customerEmail;
    let fromEmail = event.Details.ContactData.Attributes.customerPhoneNumber;
    let customerInfo = await fdcontroller().FDContactAction(encodeURIComponent(fromNumber) || encodeURIComponent(fromEmail));
    console.log(JSON.stringify(customerInfo));
    console.log("------------------------------------------------");
    return ({"customerInfo" : JSON.stringify(customerInfo)})
};
