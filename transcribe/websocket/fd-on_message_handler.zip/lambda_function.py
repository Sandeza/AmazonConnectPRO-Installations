import json
import boto3
import os


dynamodb = boto3.client('dynamodb')
client = boto3.client('translate')


def lambda_handler(event, context):
    print(json.dumps(event['body']),"body")
    message = json.loads(event['body'])['message']
    action  = json.loads(event['body'])['actions']
    target = json.loads(event['body']).get('target')
    txt = ''
    
    if action == "agentReceivedCall":
        txt =  event['requestContext']['connectionId'] 
        put_item = dynamodb.put_item(TableName=os.environ['CONNECTION_DETAILS_TABLE_NAME'], Item={'ContactId': {'S': message},
    'connectionId': {'S':txt}})

    elif action =="translate":
        response = client.translate_text(
    Text=message,
    SourceLanguageCode='auto', # or auto
    TargetLanguageCode=target)
        txt = {"type":"translate","message": response["TranslatedText"] } 
    else:
        txt ={"type":"transcribe","message": message }

        
        

    print(event['requestContext']['connectionId'])
    try:
        
        connectionIds = []

        apigatewaymanagementapi = boto3.client('apigatewaymanagementapi', 
        endpoint_url = "https://" + event["requestContext"]["domainName"] + "/" + event["requestContext"]["stage"])
        apigatewaymanagementapi.post_to_connection(
                Data=json.dumps(txt),
                ConnectionId=event['requestContext']['connectionId']
            )
           
    except Exception as e:

        print(e)

    return {}
