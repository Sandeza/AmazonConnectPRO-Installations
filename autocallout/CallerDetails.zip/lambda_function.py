import json
import boto3
import os
from boto3.dynamodb.conditions import Key, Attr
def lambda_handler(event, context):
    print(event)

    

    dynamo = boto3.resource('dynamodb')

    tabl = dynamo.Table(os.environ['callerData'])

    response = tabl.scan(FilterExpression=Attr("agentIdentifier").eq(event["agentIdentifier"]))
    
    print(response)
    return {
        'statusCode': 200,
        'body': response["Items"]
    }
